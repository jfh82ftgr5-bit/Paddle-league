PADDLE LEAGUE — ONLINE VERSION

Files to upload to GitHub:
- index.html
- manifest.webmanifest
- sw.js
- vercel.json

This version is connected to the shared Supabase backend already configured for the app.

Suggested GitHub repository name: paddle-league

After uploading these files to the repository, import that repository into Vercel and deploy it as a static site.
